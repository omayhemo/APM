#!/bin/bash

# Documentation Organization System
# Main entry point for /documentation-organize command

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
CONFIG_FILE="$PROJECT_ROOT/.apm/config/documentation-organize.yaml"
VOICE_SCRIPT="$PROJECT_ROOT/.apm/agents/voice/speakAnalyst.sh"

# Default paths
PROJECT_DOCS="${PROJECT_DOCS:-$PROJECT_ROOT/project_docs}"
INDEX_FILE="index.md"

# Function to display usage
show_usage() {
    cat << EOF
Documentation Organization System

Usage: documentation-organize [subcommand] [options]

Subcommands:
  Analysis Commands:
    scan        Scan documentation structure
    validate    Validate against standards
    graph       Generate visual representation
    orphans     Find unlinked documents

  Organization Commands:
    restructure Reorganize documentation
    link        Manage cross-references
    index       Create/update indexes
    migrate     Migrate formats/structures

  Report Commands:
    summary     Generate documentation summary
    health      Perform health check
    recommendations  Get AI-powered suggestions

Options:
  -h, --help     Show this help message
  -v, --verbose  Enable verbose output
  -d, --dry-run  Preview changes without applying

Examples:
  documentation-organize health --score
  documentation-organize scan --check-links --fix
  documentation-organize orphans --add-to-index

EOF
}

# Function to announce actions via voice
announce() {
    local message="$1"
    if [ -f "$VOICE_SCRIPT" ]; then
        bash "$VOICE_SCRIPT" "$message" 2>/dev/null
    fi
}

# Function to check dependencies
check_dependencies() {
    local missing_deps=()
    
    # Check for required tools
    command -v python3 >/dev/null 2>&1 || missing_deps+=("python3")
    command -v jq >/dev/null 2>&1 || missing_deps+=("jq")
    
    if [ ${#missing_deps[@]} -gt 0 ]; then
        echo -e "${RED}Error: Missing required dependencies:${NC}"
        printf '%s\n' "${missing_deps[@]}"
        echo "Please install missing dependencies and try again."
        exit 1
    fi
}

# Function to load configuration
load_config() {
    if [ -f "$CONFIG_FILE" ]; then
        echo -e "${BLUE}Loading configuration from $CONFIG_FILE${NC}"
        # Parse YAML config (simplified - in production would use proper YAML parser)
        PROJECT_DOCS=$(grep "project_docs:" "$CONFIG_FILE" | cut -d'"' -f2 || echo "$PROJECT_DOCS")
        INDEX_FILE=$(grep "index_file:" "$CONFIG_FILE" | cut -d'"' -f2 || echo "$INDEX_FILE")
    else
        echo -e "${YELLOW}No configuration file found. Using defaults.${NC}"
    fi
}

# Subcommand: scan
cmd_scan() {
    local verbose=false
    local check_links=false
    local fix=false
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case $1 in
            --verbose) verbose=true ;;
            --check-links) check_links=true ;;
            --fix) fix=true ;;
            *) echo "Unknown option: $1" ;;
        esac
        shift
    done
    
    announce "Scanning documentation structure"
    echo -e "${BLUE}🔍 Scanning documentation...${NC}"
    
    # Run the document parser
    python3 "$SCRIPT_DIR/doc-parser.py" scan \
        --path "$PROJECT_DOCS" \
        ${verbose:+--verbose} \
        ${check_links:+--check-links} \
        ${fix:+--fix}
}

# Subcommand: validate
cmd_validate() {
    local rules_file=""
    local strict=false
    local fix_warnings=false
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --rules) rules_file="$2"; shift ;;
            --strict) strict=true ;;
            --fix-warnings) fix_warnings=true ;;
            *) echo "Unknown option: $1" ;;
        esac
        shift
    done
    
    announce "Validating documentation against standards"
    echo -e "${BLUE}✓ Validating documentation...${NC}"
    
    python3 "$SCRIPT_DIR/doc-parser.py" validate \
        --path "$PROJECT_DOCS" \
        ${rules_file:+--rules "$rules_file"} \
        ${strict:+--strict} \
        ${fix_warnings:+--fix-warnings}
}

# Subcommand: graph
cmd_graph() {
    local format="png"
    local output=""
    local depth=""
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --format) format="$2"; shift ;;
            --output) output="$2"; shift ;;
            --depth) depth="$2"; shift ;;
            *) echo "Unknown option: $1" ;;
        esac
        shift
    done
    
    announce "Generating documentation graph"
    echo -e "${BLUE}📊 Generating documentation graph...${NC}"
    
    python3 "$SCRIPT_DIR/doc-parser.py" graph \
        --path "$PROJECT_DOCS" \
        --format "$format" \
        ${output:+--output "$output"} \
        ${depth:+--depth "$depth"}
}

# Subcommand: orphans
cmd_orphans() {
    local suggest_links=false
    local add_to_index=false
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --suggest-links) suggest_links=true ;;
            --add-to-index) add_to_index=true ;;
            *) echo "Unknown option: $1" ;;
        esac
        shift
    done
    
    announce "Finding orphaned documents"
    echo -e "${BLUE}🔍 Finding orphaned documents...${NC}"
    
    python3 "$SCRIPT_DIR/doc-parser.py" orphans \
        --path "$PROJECT_DOCS" \
        ${suggest_links:+--suggest-links} \
        ${add_to_index:+--add-to-index}
}

# Subcommand: health
cmd_health() {
    local score=false
    local fix_critical=false
    local mode="standard"
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --score) score=true ;;
            --fix-critical) fix_critical=true ;;
            --mode) mode="$2"; shift ;;
            *) echo "Unknown option: $1" ;;
        esac
        shift
    done
    
    announce "Performing documentation health check"
    echo -e "${BLUE}🏥 Checking documentation health...${NC}"
    
    python3 "$SCRIPT_DIR/doc-parser.py" health \
        --path "$PROJECT_DOCS" \
        ${score:+--score} \
        ${fix_critical:+--fix-critical} \
        --mode "$mode"
}

# Subcommand: summary
cmd_summary() {
    local format="markdown"
    local export_file=""
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --format) format="$2"; shift ;;
            --export) export_file="$2"; shift ;;
            *) echo "Unknown option: $1" ;;
        esac
        shift
    done
    
    announce "Generating documentation summary"
    echo -e "${BLUE}📋 Generating documentation summary...${NC}"
    
    python3 "$SCRIPT_DIR/doc-parser.py" summary \
        --path "$PROJECT_DOCS" \
        --format "$format" \
        ${export_file:+--export "$export_file"}
}

# Main script logic
main() {
    # Check if no arguments provided
    if [ $# -eq 0 ]; then
        show_usage
        exit 0
    fi
    
    # Parse global options
    while [[ $# -gt 0 ]] && [[ "$1" == -* ]]; do
        case $1 in
            -h|--help)
                show_usage
                exit 0
                ;;
            -v|--verbose)
                VERBOSE=true
                ;;
            -d|--dry-run)
                DRY_RUN=true
                ;;
            *)
                echo "Unknown option: $1"
                show_usage
                exit 1
                ;;
        esac
        shift
    done
    
    # Get subcommand
    SUBCOMMAND="${1:-}"
    shift || true
    
    # Check dependencies
    check_dependencies
    
    # Load configuration
    load_config
    
    # Execute subcommand
    case "$SUBCOMMAND" in
        scan)
            cmd_scan "$@"
            ;;
        validate)
            cmd_validate "$@"
            ;;
        graph)
            cmd_graph "$@"
            ;;
        orphans)
            cmd_orphans "$@"
            ;;
        health)
            cmd_health "$@"
            ;;
        summary)
            cmd_summary "$@"
            ;;
        restructure|link|index|migrate|recommendations)
            echo -e "${YELLOW}Subcommand '$SUBCOMMAND' not yet implemented${NC}"
            echo "This feature will be available in the next release."
            ;;
        *)
            echo -e "${RED}Unknown subcommand: $SUBCOMMAND${NC}"
            show_usage
            exit 1
            ;;
    esac
}

# Run main function
main "$@"